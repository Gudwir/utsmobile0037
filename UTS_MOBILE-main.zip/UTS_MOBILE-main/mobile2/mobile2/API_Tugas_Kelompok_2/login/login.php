<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type");
header("Access-Control-Allow-Methods: POST");

$host = "localhost";
$user = "root";
$pass = "";
$db = "rumah_sakit";

// Koneksi ke database
$conn = mysqli_connect($host, $user, $pass, $db);
if (!$conn) {
    echo json_encode(['status' => 'error', 'message' => 'Koneksi database gagal']);
    exit;
}

// Periksa apakah data POST tersedia
if (isset($_POST['email']) && isset($_POST['password'])) {
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Query untuk memeriksa data login
    $query = "SELECT * FROM user WHERE email = ? AND password = ?";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, "ss", $email, $password);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    if (mysqli_num_rows($result) > 0) {
        $user = mysqli_fetch_assoc($result);
        echo json_encode([
            'status' => 'success',
            'nama' => $user['nama'],
            'email' => $user['email']
        ]);
    } else {
        echo json_encode(['status' => 'failure', 'message' => 'Email atau password salah']);
    }

    mysqli_stmt_close($stmt);
} else {
    echo json_encode(['status' => 'error', 'message' => 'Data tidak lengkap']);
}
?>
