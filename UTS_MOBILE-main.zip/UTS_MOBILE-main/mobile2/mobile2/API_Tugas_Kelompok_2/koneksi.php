<?php

	$db_name = "rumah_sakit";
	$db_server = "localhost";
	$db_user = "root";
	$db_pass = "";
	
	try {
		$db = new PDO("mysql:host=$db_server;dbname=$db_name",$db_user, $db_pass);
		$db->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);
		$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	}catch(PDOException $e){
		die("koneksi gagal :". $e->getMessage());
	}
?>