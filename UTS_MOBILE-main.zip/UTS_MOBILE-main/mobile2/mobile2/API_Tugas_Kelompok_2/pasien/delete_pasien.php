<?php

header('Content-Type: application/json');
header('access-control-allow-origin: *');
header('Access-Control-Allow-Headers: *');
include '../koneksi.php';

$id = $_POST['id_pasien'];

$stmt = $db->prepare("DELETE FROM pasien WHERE id_pasien = ?");
$result = $stmt->execute([$id]);

echo json_encode([
    'id_pasien' => $id,
    'success' => $result
]);
