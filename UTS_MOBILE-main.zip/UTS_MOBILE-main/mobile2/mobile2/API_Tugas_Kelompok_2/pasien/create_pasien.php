<?php

header('Content-Type: application/json');
header('access-control-allow-origin: *');
header('Access-Control-Allow-Headers: *');
include '../koneksi.php';

$nama = $_POST['nama_pasien'];
$jenis_kelamin = $_POST['jenis_kelamin'];
$tgl_lahir = $_POST['tgl_lahir'];
$no_telp = $_POST['no_telp'];
$alamat = $_POST['alamat'];

$stmt = $db->prepare("INSERT INTO pasien (nama_pasien, alamat, no_telp, jenis_kelamin, tgl_lahir) VALUES (?, ?, ?, ?, ?)");
$result = $stmt->execute([$nama, $alamat, $no_telp, $jenis_kelamin, $tgl_lahir]);

echo json_encode(['success' => $result]);
