<?php

header('Content-Type: application/json');
header('access-control-allow-origin: *');
header('Access-Control-Allow-Headers: *');
include '../koneksi.php';

$id = $_POST['id_pasien'];
$nama_pasien = $_POST['nama_pasien'];
$alamat = $_POST['alamat'];
$no_telp = $_POST['no_telp'];
$jenis_kelamin = $_POST['jenis_kelamin'];
$tgl_lahir = $_POST['tgl_lahir'];

$stmt = $db->prepare("UPDATE pasien SET nama_pasien = ?, alamat = ?, no_telp = ?, jenis_kelamin = ?, tgl_lahir = ? WHERE id_pasien = ?");
$result = $stmt->execute([$nama_pasien, $alamat, $no_telp, $jenis_kelamin, $tgl_lahir, $id]);

echo json_encode(['success' => $result]);
