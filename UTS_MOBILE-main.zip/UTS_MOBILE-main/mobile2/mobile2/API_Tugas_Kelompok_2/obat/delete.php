<?php

    header('Content-Type: application/json');
    header('access-control-allow-origin: *');
    header('Access-Control-Allow-Headers: *');
    include '../koneksi.php';
    $id = $_POST['id_obat'];
    
    $stmt = $db->prepare("DELETE FROM obat WHERE id_obat = ? ");
    $result = $stmt->execute([$id]);
    echo json_encode([
        'id_obat' => $id,
        'success' => $result
    ]);