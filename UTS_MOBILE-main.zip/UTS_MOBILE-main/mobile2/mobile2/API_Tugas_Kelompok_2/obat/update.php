<?php

    header('Content-Type: application/json');
    header('access-control-allow-origin: *');
    header('Access-Control-Allow-Headers: *');
    include '../koneksi.php';
    $id = $_POST['id_obat'];
    $nama = $_POST['nama'];
    $deskripsi = $_POST['deskripsi'];
    $harga = (int) $_POST['harga'];
    $stok = (int) $_POST['stok'];
    $kadaluarsa = $_POST['kadaluarsa'];

    $stmt = $db->prepare("UPDATE obat SET nama = ?, deskripsi = ?, harga = ?, stok = ?, kadaluarsa = ? WHERE id_obat = ?");
    $result = $stmt->execute([$nama, $deskripsi, $harga, $stok, $kadaluarsa, $id]);
    echo json_encode(['success' => $result]);
