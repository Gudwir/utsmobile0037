<?php

    header('Content-Type: application/json');
    header('access-control-allow-origin: *');
    header('Access-Control-Allow-Headers: *');
    include '../koneksi.php';
    $stmt = $db->prepare("SELECT * FROM obat");
    $stmt->execute();
    $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo json_encode($result);