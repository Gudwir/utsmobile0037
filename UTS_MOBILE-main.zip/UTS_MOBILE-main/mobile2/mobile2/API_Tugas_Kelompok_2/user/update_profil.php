<?php

header('Content-Type: application/json');
header('access-control-allow-origin: *');
header('Access-Control-Allow-Headers: *');
include '../koneksi.php';
$email = $_POST['email'];
$nama = $_POST['nama'];

$stmt = $db->prepare("UPDATE user SET nama = ? WHERE email = ?");
$result = $stmt->execute([$nama, $email]);
echo json_encode(['success' => $result]);
