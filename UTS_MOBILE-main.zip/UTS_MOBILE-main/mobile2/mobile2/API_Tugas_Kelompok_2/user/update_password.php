<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: *');

include '../koneksi.php';

$email = $_POST['email'];
$old_password = $_POST['old_password'];
$new_password = $_POST['new_password'];

// Ambil password lama dari database
$stmt = $db->prepare("SELECT password FROM user WHERE email = ?");
$stmt->execute([$email]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if ($user && $user['password'] === $old_password) {
    // Ganti password
    $update = $db->prepare("UPDATE user SET password = ? WHERE email = ?");
    $result = $update->execute([$new_password, $email]);
    
    echo json_encode(['success' => $result]);
} else {
    // Password lama salah
    echo json_encode(['success' => false, 'message' => 'Password lama salah']);
}
