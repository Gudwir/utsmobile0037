<?php

header('Content-Type: application/json');
header('access-control-allow-origin: *');
header('Access-Control-Allow-Headers: *');
include '../koneksi.php';
    $id_dokter = $_POST['id_dokter'];
    $nama_dokter = $_POST['nama_dokter'];
    $spesialisasi = $_POST['spesialisasi'];
    $no_telp = $_POST['no_telp'];
    $alamat =  $_POST['alamat'];

$stmt = $db->prepare("UPDATE dokter SET nama_dokter = ?, spesialisasi = ?, no_telp = ?, alamat = ? WHERE id_dokter = ?");
$result = $stmt->execute([$nama_dokter, $spesialisasi, $no_telp, $alamat,  $id_dokter]);
echo json_encode(['success' => $result]);
