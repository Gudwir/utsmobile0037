import 'dart:convert';
import 'package:intl/intl.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:utsasy/Pasien/crud_pasien.dart';

class Pasien extends StatefulWidget {
  const Pasien({Key? key}) : super(key: key);

  @override
  PasienState createState() => PasienState();
}

class PasienState extends State<Pasien> {
  List _pasienList = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    refreshDataPasien();
  }

  Future<void> refreshDataPasien() async {
    setState(() => _isLoading = true);
    try {
      final response = await http.get(Uri.parse(
          "http://localhost/mobile2/API_Tugas_Kelompok_2/pasien/list_pasien.php"));

      if (response.statusCode == 200) {
        setState(() {
          _pasienList = json.decode(response.body);
        });
      } else {
        showError("Gagal memuat data. Kode: \${response.statusCode}");
      }
    } catch (e) {
      showError("Terjadi kesalahan: \$e");
    } finally {
      setState(() => _isLoading = false);
    }
  }

  void showError(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message), backgroundColor: Colors.red),
    );
  }

  Future<void> hapusDataPasien(String idPasien) async {
    final response = await http.post(
      Uri.parse(
          "http://localhost:8080/mobile2/API_Tugas_Kelompok_2/pasien/delete_pasien.php"),
      body: {'id_pasien': idPasien},
    );

    if (response.statusCode == 200) {
      refreshDataPasien();
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Data berhasil dihapus")),
      );
    } else {
      showError("Gagal menghapus data.");
    }
  }

  void confirmHapusDataPasien(String idPasien) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        content: const Text("Apakah anda yakin ingin menghapus data ini?"),
        actions: [
          ElevatedButton.icon(
            icon: const Icon(Icons.cancel),
            label: const Text("Batal"),
            style: ElevatedButton.styleFrom(
                backgroundColor: Colors.grey, foregroundColor: Colors.white),
            onPressed: () => Navigator.of(context).pop(),
          ),
          ElevatedButton.icon(
            icon: const Icon(Icons.delete),
            label: const Text("Hapus"),
            style: ElevatedButton.styleFrom(
                backgroundColor: Colors.red, foregroundColor: Colors.white),
            onPressed: () {
              Navigator.of(context).pop();
              hapusDataPasien(idPasien);
            },
          ),
        ],
      ),
    );
  }

  String formatTanggal(String tanggal) {
    try {
      final date = DateTime.parse(tanggal);
      return DateFormat('dd MMMM yyyy', 'id_ID').format(date);
    } catch (_) {
      return tanggal;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Data Pasien")),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : _pasienList.isEmpty
              ? const Center(child: Text("Data kosong"))
              : ListView.builder(
                  itemCount: _pasienList.length,
                  itemBuilder: (context, index) {
                    final pasien = _pasienList[index];
                    final tglLahir = formatTanggal(pasien['tgl_lahir']);
                    return Card(
                      margin: const EdgeInsets.all(12),
                      child: ListTile(
                        title: Text('${index + 1}. ${pasien['nama_pasien']}'),
                        subtitle: Text(
                            'JK: ${pasien['jenis_kelamin']} | Tgl Lahir: $tglLahir'),
                        trailing: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            IconButton(
                              icon: const Icon(Icons.edit, color: Colors.blue),
                              onPressed: () async {
                                final result = await Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (_) =>
                                        CrudPasien(dataPasien: pasien),
                                  ),
                                );
                                if (result == true) refreshDataPasien();
                              },
                            ),
                            IconButton(
                              icon: const Icon(Icons.delete, color: Colors.red),
                              onPressed: () {
                                confirmHapusDataPasien(
                                    pasien['id_pasien'].toString());
                              },
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
      floatingActionButton: FloatingActionButton(
        onPressed: () async {
          final result = await Navigator.push(
            context,
            MaterialPageRoute(
                builder: (_) => const CrudPasien(dataPasien: null)),
          );
          if (result == true) refreshDataPasien();
        },
        child: const Icon(Icons.add),
      ),
    );
  }
}
