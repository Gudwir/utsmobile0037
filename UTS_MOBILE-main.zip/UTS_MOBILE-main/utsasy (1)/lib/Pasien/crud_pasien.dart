import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:intl/intl.dart';

class CrudPasien extends StatefulWidget {
  final Map<String, dynamic>? dataPasien;
  const CrudPasien({Key? key, this.dataPasien}) : super(key: key);
  @override
  CrudPasienState createState() => CrudPasienState();
}

class CrudPasienState extends State<CrudPasien> {
  String status = "";
  String? jenisKelamin;
  TextEditingController namaController = TextEditingController();
  TextEditingController alamatController = TextEditingController();
  TextEditingController noTelpController = TextEditingController();
  TextEditingController tanggalLahirController = TextEditingController();

  final dateFormat = DateFormat('yyyy-MM-dd');

  @override
  void initState() {
    super.initState();
    if (widget.dataPasien != null) {
      status = "Edit Data Pasien";
      namaController.text = widget.dataPasien?['nama_pasien'] ?? '';
      alamatController.text = widget.dataPasien?['alamat'] ?? '';
      noTelpController.text = widget.dataPasien?['no_telp'] ?? '';
      tanggalLahirController.text = widget.dataPasien?['tgl_lahir'] ?? '';
      jenisKelamin = widget.dataPasien?['jenis_kelamin'] ?? 'Laki-laki';
    } else {
      status = "Tambah Data Pasien";
      jenisKelamin = 'Laki-laki';
    }
  }

  Future tambahPasien() async {
    return await http.post(
      Uri.parse(
          "http://localhost/mobile2/API_Tugas_Kelompok_2/pasien/create_pasien.php"),
      body: {
        "nama_pasien": namaController.text,
        "alamat": alamatController.text,
        "no_telp": noTelpController.text,
        "tgl_lahir": tanggalLahirController.text,
        "jenis_kelamin": jenisKelamin ?? "",
      },
    );
  }

  Future updatePasien() async {
    final idPasien = widget.dataPasien?['id_pasien'];
    if (idPasien == null) {
      tampilkanPesan("ID Pasien tidak ditemukan!", isError: true);
      return http.Response('ID Pasien Kosong', 400);
    }

    return await http.post(
      Uri.parse(
          "http://localhost:8080/mobile2/API_Tugas_Kelompok_2/pasien/update_pasien.php"),
      body: {
        "id_pasien": idPasien.toString(),
        "nama_pasien": namaController.text,
        "alamat": alamatController.text,
        "no_telp": noTelpController.text,
        "tgl_lahir": tanggalLahirController.text,
        "jenis_kelamin": jenisKelamin ?? "",
      },
    );
  }

  bool validasiInput() {
    if (namaController.text.isEmpty ||
        alamatController.text.isEmpty ||
        noTelpController.text.isEmpty ||
        tanggalLahirController.text.isEmpty ||
        jenisKelamin == null) {
      tampilkanPesan("Semua Kolom Input Wajib diisi", isError: true);
      return false;
    }
    try {
      dateFormat.parse(tanggalLahirController.text);
    } catch (_) {
      tampilkanPesan("Tanggal Lahir Tidak Valid", isError: true);
      return false;
    }
    return true;
  }

  void tampilkanPesan(String pesan, {bool isError = false}) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(pesan),
        backgroundColor: isError ? Colors.red : Colors.green,
      ),
    );
  }

  Future<void> selectDate(BuildContext context) async {
    DateTime initialDate =
        DateTime.tryParse(tanggalLahirController.text) ?? DateTime.now();
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: initialDate,
      firstDate: DateTime(1900),
      lastDate: DateTime(2100),
    );
    if (picked != null) {
      tanggalLahirController.text = dateFormat.format(picked);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(status)),
      body: Container(
        padding: const EdgeInsets.all(20),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              TextFormField(
                controller: namaController,
                decoration: const InputDecoration(labelText: "NAMA"),
              ),
              TextFormField(
                controller: alamatController,
                decoration: const InputDecoration(labelText: "ALAMAT"),
              ),
              TextFormField(
                controller: noTelpController,
                keyboardType: TextInputType.phone,
                decoration: const InputDecoration(labelText: "NO TELEPON"),
              ),
              TextFormField(
                controller: tanggalLahirController,
                readOnly: true,
                onTap: () => selectDate(context),
                decoration: const InputDecoration(labelText: "TANGGAL LAHIR"),
              ),
              const SizedBox(height: 10),
              InputDecorator(
                decoration: const InputDecoration(
                  labelText: 'JENIS KELAMIN',
                  border: UnderlineInputBorder(),
                  contentPadding: EdgeInsets.only(top: 10.0),
                ),
                child: Row(
                  children: [
                    Expanded(
                      child: RadioListTile<String>(
                        contentPadding: EdgeInsets.zero,
                        title: const Text("Laki-laki"),
                        value: "Laki-laki",
                        groupValue: jenisKelamin,
                        onChanged: (value) {
                          setState(() {
                            jenisKelamin = value;
                          });
                        },
                      ),
                    ),
                    Expanded(
                      child: RadioListTile<String>(
                        contentPadding: EdgeInsets.zero,
                        title: const Text("Perempuan"),
                        value: "Perempuan",
                        groupValue: jenisKelamin,
                        onChanged: (value) {
                          setState(() {
                            jenisKelamin = value;
                          });
                        },
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 20),
              ElevatedButton(
                onPressed: () async {
                  if (!validasiInput()) return;
                  final respon = widget.dataPasien == null
                      ? await tambahPasien()
                      : await updatePasien();

                  if (respon.statusCode == 200) {
                    tampilkanPesan(widget.dataPasien == null
                        ? "Data berhasil ditambahkan"
                        : "Data berhasil diedit");
                    Navigator.pop(context, true);
                  } else {
                    tampilkanPesan("Gagal menyimpan data", isError: true);
                  }
                },
                child: Text(widget.dataPasien == null ? "Tambah" : "Edit"),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
