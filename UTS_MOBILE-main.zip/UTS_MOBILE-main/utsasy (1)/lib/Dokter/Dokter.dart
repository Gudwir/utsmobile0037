import 'dart:convert';
import 'package:intl/intl.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:utsasy/Dokter/crud_dokter.dart';

class Dokter extends StatefulWidget {
  const Dokter({Key? key}) : super(key: key);

  @override
  DokterState createState() => DokterState();
}

class DokterState extends State<Dokter> {
  List _DokterList = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    refreshDataDokter();
  }

  Future<void> refreshDataDokter() async {
    setState(() => _isLoading = true);
    try {
      final response = await http.get(Uri.parse(
          "http://localhost/mobile2/API_Tugas_Kelompok_2/dokter/list.php"));

      if (response.statusCode == 200) {
        setState(() {
          _DokterList = json.decode(response.body);
        });
      } else {
        showError("Gagal memuat data. Kode: ${response.statusCode}");
      }
    } catch (e) {
      showError("Terjadi kesalahan: $e");
    } finally {
      setState(() => _isLoading = false);
    }
  }

  void showError(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message), backgroundColor: Colors.red),
    );
  }

  Future<void> hapusDataDokter(String id_dokter) async {
    final response = await http.post(
      Uri.parse(
          "http://localhost/mobile2/API_Tugas_Kelompok_2/dokter/delete.php"),
      body: {'id_dokter': id_dokter},
    );

    if (response.statusCode == 200) {
      refreshDataDokter();
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Data berhasil dihapus")),
      );
    } else {
      showError("Gagal menghapus data.");
    }
  }

  void confirmHapusDataDokter(String id_dokter) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        content: const Text("Apakah anda yakin ingin menghapus data ini?"),
        actions: [
          ElevatedButton.icon(
            icon: const Icon(Icons.cancel),
            label: const Text("Batal"),
            style: ElevatedButton.styleFrom(
                backgroundColor: Colors.grey, foregroundColor: Colors.white),
            onPressed: () => Navigator.of(context).pop(),
          ),
          ElevatedButton.icon(
            icon: const Icon(Icons.delete),
            label: const Text("Hapus"),
            style: ElevatedButton.styleFrom(
                backgroundColor: Colors.red, foregroundColor: Colors.white),
            onPressed: () {
              Navigator.of(context).pop();
              hapusDataDokter(id_dokter);
            },
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Data Dokter")),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : _DokterList.isEmpty
              ? const Center(child: Text("Data kosong"))
              : ListView.builder(
                  itemCount: _DokterList.length,
                  itemBuilder: (context, index) {
                    final Dokter = _DokterList[index];

                    return Card(
                      margin: const EdgeInsets.all(12),
                      child: ListTile(
                        title: Text('${index + 1}. ${Dokter['nama_dokter']}'),
                        subtitle: Text(
                            "spesialisasi: ${Dokter['spesialisasi']} | ${Dokter['no_telp']}"),
                        trailing: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            IconButton(
                              icon: const Icon(Icons.edit, color: Colors.blue),
                              onPressed: () async {
                                final result = await Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (_) =>
                                        CrudDokter(dataDokter: Dokter),
                                  ),
                                );
                                if (result == true) refreshDataDokter();
                              },
                            ),
                            IconButton(
                              icon: const Icon(Icons.delete, color: Colors.red),
                              onPressed: () {
                                confirmHapusDataDokter(Dokter['id_dokter']);
                              },
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
      floatingActionButton: FloatingActionButton(
        onPressed: () async {
          final result = await Navigator.push(
            context,
            MaterialPageRoute(
                builder: (_) => const CrudDokter(dataDokter: null)),
          );
          if (result == true) refreshDataDokter();
        },
        child: const Icon(Icons.add),
      ),
    );
  }
}
