package com.iwima.app_dbapi

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
