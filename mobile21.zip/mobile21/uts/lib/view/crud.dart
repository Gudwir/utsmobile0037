// crud.dart
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class Crud extends StatefulWidget {
  final Map<String, dynamic>? datamhs;
  const Crud({Key? key, this.datamhs}) : super(key: key);

  @override
  CrudState createState() => CrudState();
}

class CrudState extends State<Crud> {
  TextEditingController nimController = TextEditingController();
  TextEditingController namaController = TextEditingController();
  TextEditingController prodiController = TextEditingController();

  Future tambahmhs() async {
    return await http.post(
      Uri.parse("http://localhost/mobile21/create.php"),
      body: {
        "nim": nimController.text,
        "nama": namaController.text,
        "prodi": prodiController.text,
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Tambah Data Mahasiswa")),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          children: [
            TextField(
                controller: nimController,
                decoration: InputDecoration(labelText: 'NIM')),
            TextField(
                controller: namaController,
                decoration: InputDecoration(labelText: 'Nama')),
            TextField(
                controller: prodiController,
                decoration: InputDecoration(labelText: 'Prodi')),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () async {
                await tambahmhs();
                Navigator.of(context).pop();
              },
              child: Text('Tambah'),
            ),
          ],
        ),
      ),
    );
  }
}
