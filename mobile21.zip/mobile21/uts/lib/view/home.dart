// home.dart
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import './crud.dart';

class Home extends StatefulWidget {
  Home({Key? key}) : super(key: key);

  @override
  HomeState createState() => HomeState();
}

class HomeState extends State<Home> {
  @override
  void initState() {
    refreshdatamhs();
    super.initState();
  }

  // Ambil Semua Data
  List _mahasiswa = [];
  void refreshdatamhs() async {
    final hasil = await http.get(Uri.parse("http://localhost/mobile21/list.php"));
    print(hasil.statusCode);
    print(hasil.body);
    setState(() {
      _mahasiswa = json.decode(hasil.body);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Data Mahasiswa API MYSQL')),
      body: ListView.builder(
        itemCount: _mahasiswa.length,
        itemBuilder: (context, index) => Card(
          margin: const EdgeInsets.all(15),
          child: ListTile(
            title: Text(_mahasiswa[index]['nama'].toString()),
            subtitle: Text(_mahasiswa[index]['prodi'].toString()),
          ),
        ),
      ),
      floatingActionButton: FloatingActionButton(
        child: Icon(Icons.add),
        onPressed: () {
          Navigator.push<void>(
            context,
            MaterialPageRoute(
              builder: (context) => Crud(datamhs: null),
            ),
          );
        },
      ),
    );
  }
}
